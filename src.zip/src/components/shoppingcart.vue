<template>
    <div>shoppingcart@{{loginmsg}}</div>
</template>

<script>
    export default {
        name: "shoppingcart",
        props:['loginmsg']
    }
</script>