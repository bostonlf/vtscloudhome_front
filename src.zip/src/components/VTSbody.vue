<template>
   <article>This is a component example</article>
</template>

<script>
    export default {
        name: "VTSbody",
        props:['loginmsg']
    }
</script>