<template>
    <div>login@{{loginmsg}}</div>
</template>

<script>
    export default {
        name: "login",
        props:['loginmsg']
    }
</script>