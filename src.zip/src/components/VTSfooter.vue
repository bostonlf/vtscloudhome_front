<template>
    <footer>VTSfooter</footer>
</template>

<script>
    export default {
        name: "VTSfooter",
        props:['loginmsg']
    }
</script>