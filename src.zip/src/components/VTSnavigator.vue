<template>

<nav>  
    
<a href="#/route/HomePage">HomePage</a> |
<a href="#/route/Person">Person</a> |
<a href="#/route/Request">Request</a> |
<a href="#/route/Task">Task</a>| 
<a href="#/route/User">User</a>

</nav>

</template>

<script>
    export default {
        name: "VTSnavigator",
        props:['loginmsg']
    }
</script>   